
import navbar from "./components/navbar.js";
import footer from "./components/footer.js";
import home from "./paginas/home.js";
import contato from "./paginas/contato.js";

const app = document.createElement('div')
app.id = "app"
app.appendChild(home())
window.addEventListener('hashchange', () =>{
    if(location.hash == "#home"){
        app.appendChild(home())
    }else if(location.hash == "#contato"){
        app.appendChild(contato())
    }
})
function limparCorpo(){
   const elemento = document.getElementById("app");
    if(elemento){
        elemento.remove();
    }
}
document.body.appendChild(navbar())
document.body.appendChild(app)
document.body.appendChild(footer())
// document.body.insertAdjacentElement('beforebegin', navbar);
// document.body.insertAdjacentElement('afterbegin', main)
// document.body.insertAdjacentElement('afterend', footer);
