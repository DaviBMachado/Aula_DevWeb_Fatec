export default function navbar() {
    const navbar = document.createElement('nav');
    navbar.classList.add('light-blue', 'lighten-1');
    navbar.innerHTML = `
    <div role="navigation">
        <div class="nav-wrapper container"><a id="logo-container" href="#" class="brand-logo">Logo</a>
        <ul class="right hide-on-med-and-down">
            <li><a href="#home">Inicial</a></li>
            <li><a href="#contato">Contato</a></li>
        </ul>

        <ul id="nav-mobile" class="sidenav">
            <li><a href="#home">Inicial</a></li>
            <li><a href="#contato">Contato</a></li>
        </ul>
        <a href="#" data-target="nav-mobile" class="sidenav-trigger"><i class="material-icons">menu</i></a>
        </div>
    </div>
    `
return navbar
}